#!/usr/bin/python
# -*- coding: utf-8 -*-


import os, sys, inspect
import numpy as np
import matplotlib.pyplot as plt

currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.insert(0, parentdir)

import json, shutil


def cal_qoe(x=0, run_dir=None):
    block_data = []
    qoe = .0
    miss_num={"H_miss_num":0,"M_miss_num":0,"L_miss_num":0}
    delay= {"H_delay":0,"M_delay":0,"L_delay":0}
    delay_num={"H_delay_num":0,"M_delay_num":0,"L_delay_num":0}
    avg_delay=dict()
    y1=[]
    y2=[]
    tmp = [3, 2, 1]
    if run_dir:
        if run_dir[-1] != '/':
            run_dir += '/'
    else:
        run_dir = './'
    with open(run_dir + "output/block.log", "r") as f:
        for line in f.readlines():
            data = json.loads(line.replace("'", '"'))
            # not finished
            if data["Miss_ddl"] == 0 and data["Size"] - data["Finished_bytes"] > 0.000001:
                continue
            block_data.append(data)
    for block in block_data:        
        priority = float(tmp[int(block['Priority'])] / 3)
        if block["Miss_ddl"] == 0:
            qoe += priority
            if priority == 1.0:
                y2.append(block["Latency"])
                delay["H_delay"] += block["Latency"]
                delay_num["H_delay_num"] += 1
            elif priority == (2.0 / 3):
                delay["M_delay"] += block["Latency"]
                delay_num["M_delay_num"] += 1
            elif priority == (1.0 / 3):
                y1.append(block["Latency"])
                delay["L_delay"] += block["Latency"]
                delay_num["L_delay_num"] += 1
            else:
                print("WRONG priority for delay!")
                exit(1)
        elif abs(x) > 0.00001:
            qoe -= x*priority
        else:
            if priority == 1.0:
                miss_num["H_miss_num"]+=1
            elif priority == 2.0 / 3:
                miss_num["M_miss_num"]+=1
            elif priority == 1.0 /3:
                miss_num["L_miss_num"]+=1
            else:
                print("WRONG priority for delay!")
                exit(1)
    a = np.mean(y1)
    b = np.mean(y2)

    # avg_delay["H_avg_delay"] = float(delay["H_delay"] / delay_num["H_delay_num"])
    avg_delay["H_avg_delay"] = b
    avg_delay["M_avg_delay"] = float(delay["M_delay"] / delay_num["M_delay_num"])
    # avg_delay["L_avg_delay"] = float(delay["L_delay"] / delay_num["L_delay_num"])
    avg_delay["L_avg_delay"] = a

    with open("./miss_num_info.log","a") as f:
        f.write(json.dumps(miss_num) + '\n')
    with open("./avg_delay_info.log","a") as f:
        f.write(json.dumps(avg_delay) + '\n')
    return qoe

def aitrans_cal_qoe(x=0.9, run_dir=None):
    block_data = []
    urgency = []
    priorities = []
    qoe = 0
    tmp = [3, 2, 1]
    if run_dir:
        if run_dir[-1] != '/':
            run_dir += '/'
    else:
        run_dir = './'
    with open(run_dir + "output/block.log", "r") as f:
        for line in f.readlines():
            data = json.loads(line.replace("'", '"'))
            # not finished
            if data["Miss_ddl"] == 0 and data["Size"] - data["Finished_bytes"] > 0.000001:
                continue
            block_data.append(data)
    for block in block_data:
        priority = float(tmp[int(block['Priority'])] / 3)
        priorities.append(priority)
        if block["Miss_ddl"] == 0:
            urgency.append(1)
        else:
            urgency.append(0)
            priorities[-1] *= 0
    for i in range(len(urgency)):
        qoe += x * priorities[i] + (1 - x) * urgency[i]
    return qoe
