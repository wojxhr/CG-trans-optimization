from player.block_selection import Solution as BlockSelection
from player.examples.reno import Reno


class Solution(Reno, BlockSelection):
    pass
